package java_final_project;

import java.util.HashMap;
import java.util.Map;

public class ExternalLibrarySystem {
    private Map<String, Boolean> externalBooks;

    public ExternalLibrarySystem() {
        externalBooks = new HashMap<>();
        // Sample external library books availability
        externalBooks.put("9781234567890", true);
        externalBooks.put("9781234567891", false);
        externalBooks.put("9781234567892", true);
        externalBooks.put("9781234567893", false);
        externalBooks.put("9781234567894", true);
        externalBooks.put("9781234567895", true);
        externalBooks.put("9781234567896", false);
        externalBooks.put("9781234567897", true);
        externalBooks.put("9781234567898", true);
        externalBooks.put("9781234567899", false);
    }

    public boolean isBookAvailable(String isbn) {
        return externalBooks.getOrDefault(isbn, false);
    }
}

