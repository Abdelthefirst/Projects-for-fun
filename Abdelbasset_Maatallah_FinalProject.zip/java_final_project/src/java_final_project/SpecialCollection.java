package java_final_project;

public class SpecialCollection {
    private String name;
    private boolean available;

    public SpecialCollection(String name, boolean available) {
        this.name = name;
        this.available = available;
    }

    public String getName() {
        return name;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    @Override
    public String toString() {
        return "SpecialCollection{" +
                "name='" + name + '\'' +
                ", available=" + available +
                '}';
    }
}
