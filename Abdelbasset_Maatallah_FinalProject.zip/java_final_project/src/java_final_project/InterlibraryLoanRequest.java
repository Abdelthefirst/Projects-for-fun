package java_final_project;
public class InterlibraryLoanRequest {
    private String studentId;
    private String bookTitle;
    private boolean fulfilled;

    public InterlibraryLoanRequest(String studentId, String bookTitle) {
        this.studentId = studentId;
        this.bookTitle = bookTitle;
        this.fulfilled = false;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public boolean isFulfilled() {
        return fulfilled;
    }

    public void setFulfilled(boolean fulfilled) {
        this.fulfilled = fulfilled;
    }

    @Override
    public String toString() {
        return "InterlibraryLoanRequest{" +
                "studentId='" + studentId + '\'' +
                ", bookTitle='" + bookTitle + '\'' +
                ", fulfilled=" + fulfilled +
                '}';
    }
}

