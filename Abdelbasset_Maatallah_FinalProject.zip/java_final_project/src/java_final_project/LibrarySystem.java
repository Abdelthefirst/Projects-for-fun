package java_final_project;
import java.util.*;
import java.io.*;

public class LibrarySystem {
    private static Scanner scanner = new Scanner(System.in);
    private static Library library = new Library();
    private static ExternalLibrarySystem externalLibrarySystem = new ExternalLibrarySystem();

    public static void main(String[] args) {
        // Load data from TXT files
        library.loadBooksFromTXT("books.txt");
        library.loadStudentsFromTXT("students.txt");
        library.loadStaffFromTXT("staff.txt");
        library.loadStudentCredentialsFromTXT("student_credentials.txt");
        library.loadStaffCredentialsFromTXT("staff_credentials.txt");

        while (true) {
            System.out.println("Welcome to the National Library System");
            System.out.print("Loading");
            try {
                for (int i = 0; i < 3; i++) {
                    Thread.sleep(1000);
                    System.out.print(".");
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println();

            System.out.println("Are you a student or staff? (Enter 'student' or 'staff')");
            String userType = scanner.nextLine();

            boolean authenticated = false;
            if ("student".equalsIgnoreCase(userType)) {
                authenticated = authenticateUser(library.getStudentCredentials());
            } else if ("staff".equalsIgnoreCase(userType)) {
                authenticated = authenticateUser(library.getStaffCredentials());
            } else {
                System.out.println("Invalid user type. Please try again.");
                continue;
            }

            if (authenticated) {
                displayDashboard();
            } else {
                System.out.println("Authentication failed. Please try again later.");
            }
        }
    }

    private static boolean authenticateUser(Map<String, String> credentials) {
        int attempts = 0;
        while (attempts < 5) {
            System.out.print("Enter username: ");
            String username = scanner.nextLine();
            System.out.print("Enter password: ");
            String password = scanner.nextLine();

            if (credentials.containsKey(username) && credentials.get(username).equals(password)) {
                return true;
            } else {
                System.out.println("Incorrect Password, Try Again");
                attempts++;
            }
        }

        System.out.println("Too many failed attempts. Please wait for 30 seconds.");
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return false;
    }

    private static void displayDashboard() {
        while (true) {
            System.out.println("\nLibrary Dashboard");
            System.out.println("1. View all books");
            System.out.println("2. Search for a book");
            System.out.println("3. Check out a book");
            System.out.println("4. Check in a book");
            System.out.println("5. Register a student");
            System.out.println("6. Update book quantity");
            System.out.println("7. Access special collection");
            System.out.println("8. View all students");
            System.out.println("9. View all staff");
            System.out.println("10. Request interlibrary loan");
            System.out.println("11. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    viewAllBooks();
                    break;
                case 2:
                    searchBook();
                    break;
                case 3:
                    checkOutBook();
                    break;
                case 4:
                    checkInBook();
                    break;
                case 5:
                    registerStudent();
                    break;
                case 6:
                    updateBookQuantity();
                    break;
                case 7:
                    accessSpecialCollection();
                    break;
                case 8:
                    viewAllStudents();
                    break;
                case 9:
                    viewAllStaff();
                    break;
                case 10:
                    requestInterlibraryLoan();
                    break;
                case 11:
                    System.out.println("Exiting the system. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void viewAllBooks() {
        List<Book> books = library.getAllBooks();
        for (Book book : books) {
            System.out.println(book);
        }
    }

    private static void searchBook() {
        System.out.print("Enter the title of the book: ");
        String title = scanner.nextLine();
        Book book = library.searchBook(title);
        if (book != null) {
            System.out.println(book);
        } else {
            System.out.println("Book not found.");
        }
    }

    private static void checkOutBook() {
        System.out.print("Enter the title of the book to check out: ");
        String title = scanner.nextLine();
        System.out.print("Enter your student ID: ");
        String studentID = scanner.nextLine();
        boolean success = library.checkOutBook(title, studentID);
        if (success) {
            System.out.println("Book checked out successfully.");
        } else {
            System.out.println("Book could not be checked out.");
        }
    }

    private static void checkInBook() {
        System.out.print("Enter the title of the book to check in: ");
        String title = scanner.nextLine();
        boolean success = library.checkInBook(title);
        if (success) {
            System.out.println("Book checked in successfully.");
        } else {
            System.out.println("Book could not be checked in.");
        }
    }

    private static void registerStudent() {
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        System.out.print("Enter student email: ");
        String email = scanner.nextLine();
        System.out.print("Enter student phone number: ");
        String phoneNumber = scanner.nextLine();
        library.registerStudent(new Student(id, name, email, phoneNumber));
        System.out.println("Student registered successfully.");
    }

    private static void updateBookQuantity() {
        System.out.print("Enter the title of the book: ");
        String title = scanner.nextLine();
        System.out.print("Enter the new quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // consume newline
        library.updateBookQuantity(title, quantity);
    }

    private static void accessSpecialCollection() {
        System.out.print("Enter your library card number: ");
        String cardNumber = scanner.nextLine();
        boolean success = library.requestAccessToSpecialCollection(cardNumber);
        if (success) {
            System.out.println("Access granted to special collection.");
        } else {
            System.out.println("Access denied to special collection.");
        }
    }

    private static void viewAllStudents() {
        List<Student> students = library.getAllStudents();
        for (Student student : students) {
            System.out.println(student);
        }
    }

    private static void viewAllStaff() {
        List<Staff> staff = library.getAllStaff();
        for (Staff staffMember : staff) {
            System.out.println(staffMember);
        }
    }

    private static void requestInterlibraryLoan() {
        List<Book> books = library.getAllBooks();
        System.out.println("Available books for interlibrary loan:");
        for (int i = 0; i < books.size(); i++) {
            System.out.println((i + 1) + ". " + books.get(i).getTitle());
        }
        System.out.print("Enter the number of the book you want to request: ");
        int bookNumber = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (bookNumber < 1 || bookNumber > books.size()) {
            System.out.println("Invalid book number.");
            return;
        }

        Book selectedBook = books.get(bookNumber - 1);
        boolean success = externalLibrarySystem.isBookAvailable(selectedBook.getIsbn());

        if (success) {
            System.out.println("Transaction succeeded.... the interlibrary loan has been completed.");
        } else {
            System.out.println("Transaction failed.... For additional support please contact Library staff.");
        }
    }
}
