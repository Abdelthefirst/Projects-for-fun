package java_final_project;
import java.io.*;
import java.util.*;

public class Library {
    private List<Book> books = new ArrayList<>();
    private List<Student> students = new ArrayList<>();
    private List<Staff> staff = new ArrayList<>();
    private Map<String, String> studentCredentials = new HashMap<>();
    private Map<String, String> staffCredentials = new HashMap<>();
    private ExternalLibrarySystem externalLibrarySystem = new ExternalLibrarySystem();

    public void loadBooksFromTXT(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip the header line
                }
                String[] data = line.split(",");
                if (data.length == 6) {
                    String isbn = data[0];
                    String title = data[1];
                    String author = data[2];
                    int publicationYear = Integer.parseInt(data[3]);
                    boolean isAvailable = Boolean.parseBoolean(data[4]);
                    int quantity = Integer.parseInt(data[5]);
                    books.add(new Book(isbn, title, author, publicationYear, isAvailable, quantity));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadStudentsFromTXT(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip the header line
                }
                String[] data = line.split(",");
                if (data.length == 4) {
                    String id = data[0];
                    String name = data[1];
                    String email = data[2];
                    String phoneNumber = data[3];
                    students.add(new Student(id, name, email, phoneNumber));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadStaffFromTXT(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip the header line
                }
                String[] data = line.split(",");
                if (data.length == 4) {
                    String id = data[0];
                    String name = data[1];
                    String position = data[2];
                    String email = data[3];
                    staff.add(new Staff(id, name, position, email));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadStudentCredentialsFromTXT(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip the header line
                }
                String[] data = line.split(",");
                if (data.length == 2) {
                    String username = data[0];
                    String password = data[1];
                    studentCredentials.put(username, password);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadStaffCredentialsFromTXT(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip the header line
                }
                String[] data = line.split(",");
                if (data.length == 2) {
                    String username = data[0];
                    String password = data[1];
                    staffCredentials.put(username, password);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Book> getAllBooks() {
        return books;
    }

    public List<Student> getAllStudents() {
        return students;
    }

    public List<Staff> getAllStaff() {
        return staff;
    }

    public Book searchBook(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public boolean checkOutBook(String title, String studentID) {
        Book book = searchBook(title);
        if (book != null && book.isAvailable() && book.getQuantity() > 0) {
            book.setQuantity(book.getQuantity() - 1);
            if (book.getQuantity() == 0) {
                book.setAvailable(false);
            }
            return true;
        }
        return false;
    }

    public boolean checkInBook(String title) {
        Book book = searchBook(title);
        if (book != null) {
            book.setQuantity(book.getQuantity() + 1);
            book.setAvailable(true);
            return true;
        }
        return false;
    }

    public void registerStudent(Student student) {
        students.add(student);
    }

    public void updateBookQuantity(String title, int quantity) {
        Book book = searchBook(title);
        if (book != null) {
            book.setQuantity(quantity);
            book.setAvailable(quantity > 0);
        }
    }

    public boolean requestAccessToSpecialCollection(String cardNumber) {
        // Implement your logic for special collection access
        return true;
    }

    public Map<String, String> getStudentCredentials() {
        return studentCredentials;
    }

    public Map<String, String> getStaffCredentials() {
        return staffCredentials;
    }
}
